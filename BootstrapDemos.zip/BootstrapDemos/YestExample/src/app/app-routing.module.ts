import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddProductComponent } from './add-product/add-product.component';
import { DisplayComponent } from './display/display.component';
import {Routes, RouterModule} from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/add-product', pathMatch: 'full' },
  { path: 'add-product', component: AddProductComponent},
  { path: 'display', component: DisplayComponent},
  { path: '**', component: DisplayComponent, pathMatch: 'full'}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
