import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../model/product-model';
import { ProductService } from '../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  productArr: ProductModel[];
  productToBeEdited: ProductModel;
  submitHideShowStatus = false;
  searchProductId;
  searchedProduct: ProductModel;
  hideResult = false;
  constructor(private productService: ProductService, private router: Router) {
    this.productArr = [];
    this.searchedProduct = new ProductModel();
  }

  ngOnInit() {
    this.productArr = this.productService.display();
  }
  deleteProduct(index: number) {
    this.submitHideShowStatus = false;
    this.productService.delete(index);
  }
  editProduct(productId: number) {
    this.submitHideShowStatus = true;
    this.productToBeEdited = this.productService.edit(productId);
  }
  navigateToAddProduct() {
    this.router.navigate(['/add-product']);
  }
  search(productId) {
    this.searchedProduct = this.productService.searchProduct(productId);
    this.hideResult = true;
  }
  sort() {
    this.productArr = this.productService.sortByProductId();
  }
}
