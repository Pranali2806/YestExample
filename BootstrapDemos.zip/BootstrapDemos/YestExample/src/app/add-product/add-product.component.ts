import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ProductModel } from '../model/product-model';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  @Input() product: ProductModel;
  @Input() submitHideShowStatus = false;
  @Output() emitStatus = new EventEmitter;

  constructor(private productService: ProductService) {
    this.product = new ProductModel();
    this.product.productName = 'Pencil';
  }

  ngOnInit() {
  }
  add() {
    this.productService.add(this.product);
  }
  update() {
    alert('Updated product successfully');
    this.submitHideShowStatus = false;
    this.product = new ProductModel();
    this.emitStatus.emit();
  }
}
