export class ProductModel {
    productId: number;
    productName: String;
    productPrice: Number;
    productQuantity: Number;
}
