import { Injectable } from '@angular/core';
import { ProductModel } from '../model/product-model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productArray: ProductModel[];
  searchResult: ProductModel;
  constructor(private router: Router) {
    this.productArray = [];
  }
  add(product: ProductModel) {
      alert('Added product successfully');
      this.productArray.push(product);
      this.router.navigate(['/display']);
  }
  display() {
    return this.productArray;
  }
  delete(index: number)  {
      this.productArray.splice(index, 1);
  }
  edit(productId: number) {
    return this.productArray.find(x => x.productId === productId);
  }
  searchProduct(productId) {
    this.searchResult = this.productArray.find(x => x.productId === productId);
    if (this.searchResult === null) {
      return null;
    } else {
      return this.searchResult;
    }
  }

  sortByProductId() {
    this.productArray.sort((a, b) => a.productId > b.productId ? 1 : ((a.productId < b.productId) ? -1 : 0));
    return this.productArray;
  }
}

